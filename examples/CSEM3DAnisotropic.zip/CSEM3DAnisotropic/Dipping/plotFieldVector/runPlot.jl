#------------------------------------------------------------------------------
# script to plot CSEM forward modeling results
#------------------------------------------------------------------------------

using Plots
using Printf
using DSP
#------------------------------------------------------------------------------

include("readMesh.jl")
include("readEdgeFields.jl")
include("getFaceCenterEfield.jl")
include("getYZplane.jl")


# First, read the mesh file
println("Reading mesh file ...")
@time mesh = readMesh("mesh.mesh")

# Second, read the primary fields
EpFile = "Ep.txt"
println("Reading Ep field file ...")
@time epField, gridSize = readEdgeFields(EpFile)

# Third, read the secondary fields
EsFile = "E_sedTID_60.field"
println("Reading Es field file ...")
@time eField,           = readEdgeFields(EsFile)

eField += epField  # get the total field


# 4th, select a period and a polarization mode
freqID = 1  # 0.25Hz
txID   = 1  # inline

println("Getting face center E field ...")
@time (), (), (), (), eYZ_ey, eYZ_ez = getFaceCenterEfield(gridSize, eField, txID, freqID)

# select a specific y-z section
xfix = 0
yrange = [-6400 6400]
zrange = [0 4500]

println("Extracting the fields of selected plane ...")
@time YY, ZZ, AMP, ey0n, ez0n = getYZplane(xfix, yrange, zrange, mesh, eYZ_ey, eYZ_ez)


# Then, prepare for plotting
# choose a plotting backend: PlotlyJS, GR, PyPlot, etc
# plotlyjs()
# gr()
pyplot()

labelfontsize  = 14
tickfontsize   = 11

w2h = (yrange[2]-yrange[1])/(zrange[2]-zrange[1])
window_h = 280
window_w = window_h * w2h

# plot the contours.
p1 = contourf(YY, ZZ, AMP,
              levels=100,
              yflip=true,
              c = :jet1,
              clims = (-16, -8),
              aspect_ratio=:equal,
              xlabel = "y (km)",
              ylabel = "z (km)",
			  labelfontsize  = labelfontsize,
		      tickfontsize   = tickfontsize,
              #cbar = colorbar(ticks=collect(-16:2:-8)),
              #colorbar_title = "Amplitude, log10 (V/m)",
              foreground_color_grid=RGB(0.8, 0.8, 0.8),
              gridstyle=:dash,
              ylims = (-0.2, 4.3),
              yticks = collect(0:4),
              xticks = collect(-6:2:6),
              windowsize = (window_w, window_h))

# plot the vectors.
quiver!(YY[1:2:end, 1:2:end][:], ZZ[1:2:end, 1:2:end][:],
        quiver = (ey0n[1:2:end, 1:2:end][:]*0.15, ez0n[1:2:end, 1:2:end][:]*0.15),
        c = RGB(0.15, 0.15, 0.15),
        linewidth = 0.35,
        arrow = 0.15)


# plot the outline of the rectangle anomaly.
yloc = [-3, 3, 3, -3, -3]
zloc = [2, 2, 2.1, 2.1, 2]
plot!(yloc, zloc, c=:black, legend = false)


# plot the seawater-sediment interface.
plot!([-6.4, 6.4], [1, 1], c=:black, legend = false)

# plot the long arrow
alen   = 3.0    # arrow lenth
angle  = 60.0   # arrow angle
# startPoint = [3, 1]
quiver!([3], [1],
        quiver = ([alen*cosd(angle)], [alen*sind(angle)]),
        c = :black,
        linewidth = 0.8,
        )

savefig(p1, "Eyz_60.pdf")
savefig(p1, "Eyz_60.eps")
