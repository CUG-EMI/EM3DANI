#------------------------------------------------------------------------------
# script to plot CSEM forward modeling results
#------------------------------------------------------------------------------

using Plots
using Printf
using DSP   # providing unwrap function
#------------------------------------------------------------------------------

include("readCSEMResp.jl")
include("getAmpPhs.jl")


# First, read the forward response file
respfile0  = "0.25Hz_inline_broadside_MUMPS_beta0.resp"
respfile30 = "0.25Hz_inline_broadside_MUMPS_beta30.resp"
respfile45 = "0.25Hz_inline_broadside_MUMPS_beta45.resp"
respfile60 = "0.25Hz_inline_broadside_MUMPS_beta60.resp"
respfile90 = "0.25Hz_inline_broadside_MUMPS_beta90.resp"

dataInfo, resp0 = readCSEMResp(respfile0)
(), resp30 = readCSEMResp(respfile30)
(), resp45 = readCSEMResp(respfile45)
(), resp60 = readCSEMResp(respfile60)
(), resp90 = readCSEMResp(respfile90)


# Second, select the forward response
# ------------------------ inline ------------------------- #
freqID = 1
txID   = 1
offset = dataInfo.rxLoc[:, 2]
txRange = [-8000, 8000]
rxID1 = findall(x -> x>=txRange[1] && x<=txRange[2], offset)
rxID2 = findall(x -> x>=200, abs.(offset .- dataInfo.txLoc[1,2])) # exclude receivers too close to the transmitter
rxID = intersect(rxID1, rxID2)


# Ey
Ey0_amp,  Ey0_phs  = getAmpPhs(resp0.Ey[rxID, txID, freqID])
Ey30_amp, Ey30_phs = getAmpPhs(resp30.Ey[rxID, txID, freqID])
Ey45_amp, Ey45_phs = getAmpPhs(resp45.Ey[rxID, txID, freqID])
Ey60_amp, Ey60_phs = getAmpPhs(resp60.Ey[rxID, txID, freqID])
Ey90_amp, Ey90_phs = getAmpPhs(resp90.Ey[rxID, txID, freqID])

Ey0_phs = Ey0_phs .- 360

# Bx
Bx0_amp,  Bx0_phs  = getAmpPhs(resp0.Bx[rxID, txID, freqID])
Bx30_amp, Bx30_phs = getAmpPhs(resp30.Bx[rxID, txID, freqID])
Bx45_amp, Bx45_phs = getAmpPhs(resp45.Bx[rxID, txID, freqID])
Bx60_amp, Bx60_phs = getAmpPhs(resp60.Bx[rxID, txID, freqID])
Bx90_amp, Bx90_phs = getAmpPhs(resp90.Bx[rxID, txID, freqID])
# --------------------------------------------------------- #

# Third, prepare for plotting

# choose a plotting backend: PlotlyJS, GR, PyPlot, etc
# plotlyjs()
# gr()
pyplot()

# pre-set some plotting attributes
labelfontsize  = 16
legendfontsize = 12
tickfontsize   = 13
linewidth = 1.5

c1 = RGB(0, 0, 0.5625)
c2 = RGB(0, 0.5625, 1)
c3 = RGB(0.5, 1, 0.5)
c4 = RGB(1, 0.5, 0)
c5 = RGB(0.5, 0, 0)

x = offset[rxID]/1000


#------------ 1st, Ey Amplitude ------------#
pltEyamp = plot(
            x,
            log10.([Ey0_amp Ey30_amp Ey45_amp Ey60_amp Ey90_amp]),
            label = ["0"   "30"   "45"   "60"  "90"],
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "log10 (Amplitude (V/m))",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyamp, "Eyamp.pdf")


#-------------- 2nd, Ey Phase --------------#
pltEyphs = plot(
            x,
            [Ey0_phs Ey30_phs Ey45_phs Ey60_phs Ey90_phs],
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Phase (degree)",
            labelfontsize  = labelfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyphs, "Eyphs.pdf")


#------------ 3rd, Bx Amplitude ------------#
pltBxamp = plot(
            x,
            log10.([Bx0_amp Bx30_amp Bx45_amp Bx60_amp Bx90_amp]),
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "log10 (Amplitude (T))",
            labelfontsize  = labelfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltBxamp, "Bxamp.pdf")


#-------------- 4th, Bx Phase --------------#
pltBxphs = plot(
            x,
            [Bx0_phs Bx30_phs Bx45_phs Bx60_phs Bx90_phs],
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Phase (degree)",
            labelfontsize  = labelfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltBxphs, "Bxphs.pdf")

#
savefig(pltEyamp, "Eyamp.eps")
savefig(pltEyphs, "Eyphs.eps")
savefig(pltBxamp, "Bxamp.eps")
savefig(pltBxphs, "Bxphs.eps")



# ======================= Plot normalized responses =======================#
# 1D background and 3D isotropic responses are for normalization purpose
respfile1D = "canonical1D_dp1d.resp"
respfile3D = "canonical3D_sedISO.resp"
(), resp1d = readCSEMResp(respfile1D)
(), resp3d = readCSEMResp(respfile3D)

Ey1d_amp,    = getAmpPhs(resp1d.Ey[rxID, txID, freqID])
Ey3d_amp,    = getAmpPhs(resp3d.Ey[rxID, txID, freqID])
Bx1d_amp,    = getAmpPhs(resp1d.Bx[rxID, txID, freqID])
Bx3d_amp,    = getAmpPhs(resp3d.Bx[rxID, txID, freqID])

# Ey0_n1d  = Ey0_amp  ./ Ey1d_amp
Ey30_n1d = Ey30_amp ./ Ey1d_amp
Ey45_n1d = Ey45_amp ./ Ey1d_amp
Ey60_n1d = Ey60_amp ./ Ey1d_amp
Ey90_n1d = Ey90_amp ./ Ey1d_amp

Ey30_n3d = Ey30_amp ./ Ey3d_amp
Ey45_n3d = Ey45_amp ./ Ey3d_amp
Ey60_n3d = Ey60_amp ./ Ey3d_amp
Ey90_n3d = Ey90_amp ./ Ey3d_amp

Bx30_n1d = Bx30_amp ./ Bx1d_amp
Bx45_n1d = Bx45_amp ./ Bx1d_amp
Bx60_n1d = Bx60_amp ./ Bx1d_amp
Bx90_n1d = Bx90_amp ./ Bx1d_amp

Bx30_n3d = Bx30_amp ./ Bx3d_amp
Bx45_n3d = Bx45_amp ./ Bx3d_amp
Bx60_n3d = Bx60_amp ./ Bx3d_amp
Bx90_n3d = Bx90_amp ./ Bx3d_amp


#------------ Ey normalized Amplitude ------------#
pltEyNorAmp = plot(
            x,
            [Ey30_n1d Ey30_n3d Ey45_n1d Ey45_n3d Ey60_n1d Ey60_n3d Ey90_n1d Ey90_n3d],
            # label = ["0"   "30"   "45"   "60"  "90"],
            legend = false,
            color = [c2 c2 c3 c3 c4 c4 c5 c5],
            linestyle = [:solid :dash],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Normalized field",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyNorAmp, "EyNorAmp.pdf")


#------------ Bx normalized Amplitude ------------#
pltBxNorAmp = plot(
            x,
            [Bx30_n1d Bx30_n3d Bx45_n1d Bx45_n3d Bx60_n1d Bx60_n3d Bx90_n1d Bx90_n3d],
            legend = false,
            color = [c2 c2 c3 c3 c4 c4 c5 c5],
            linestyle = [:solid :dash],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Normalized field",
            labelfontsize  = labelfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltBxNorAmp, "BxNorAmp.pdf")

#
savefig(pltEyNorAmp, "EyNorAmp.eps")
savefig(pltBxNorAmp, "BxNorAmp.eps")
