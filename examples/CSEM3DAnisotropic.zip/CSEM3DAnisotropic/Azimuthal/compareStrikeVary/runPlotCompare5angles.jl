#------------------------------------------------------------------------------
# script to plot CSEM forward modeling results
#------------------------------------------------------------------------------

using Plots
using Printf
using DSP   # providing unwrap function
#------------------------------------------------------------------------------

include("readCSEMResp.jl")
include("getAmpPhs.jl")


# First, read the forward response file
respfile0  = "0.25Hz_inline_broadside_MUMPS_alpha0.resp"
respfile30 = "0.25Hz_inline_broadside_MUMPS_alpha30.resp"
respfile45 = "0.25Hz_inline_broadside_MUMPS_alpha45.resp"
respfile60 = "0.25Hz_inline_broadside_MUMPS_alpha60.resp"
respfile90 = "0.25Hz_inline_broadside_MUMPS_alpha90.resp"

dataInfo, resp0 = readCSEMResp(respfile0)
(), resp30 = readCSEMResp(respfile30)
(), resp45 = readCSEMResp(respfile45)
(), resp60 = readCSEMResp(respfile60)
(), resp90 = readCSEMResp(respfile90)


# Second, select the forward response
# ------------------------ inline ------------------------- #
freqID = 1
txID   = 1
offset = dataInfo.rxLoc[:, 2]
txRange = [-8000, 8000]
rxID1 = findall(x -> x>=txRange[1] && x<=txRange[2], offset)
rxID2 = findall(x -> x>=200, abs.(offset .- dataInfo.txLoc[1,2])) # exclude receivers too close to the transmitter
rxID = intersect(rxID1, rxID2)


# Ey
Ey0_amp,  Ey0_phs  = getAmpPhs(resp0.Ey[rxID, txID, freqID])
Ey30_amp, Ey30_phs = getAmpPhs(resp30.Ey[rxID, txID, freqID])
Ey45_amp, Ey45_phs = getAmpPhs(resp45.Ey[rxID, txID, freqID])
Ey60_amp, Ey60_phs = getAmpPhs(resp60.Ey[rxID, txID, freqID])
Ey90_amp, Ey90_phs = getAmpPhs(resp90.Ey[rxID, txID, freqID])


# ------------------------ broadside ------------------------- #
# Ex
txID   = 2
Ex0_amp,  Ex0_phs  = getAmpPhs(resp0.Ex[rxID, txID, freqID])
Ex30_amp, Ex30_phs = getAmpPhs(resp30.Ex[rxID, txID, freqID])
Ex45_amp, Ex45_phs = getAmpPhs(resp45.Ex[rxID, txID, freqID])
Ex60_amp, Ex60_phs = getAmpPhs(resp60.Ex[rxID, txID, freqID])
Ex90_amp, Ex90_phs = getAmpPhs(resp90.Ex[rxID, txID, freqID])
# --------------------------------------------------------- #


# Third, prepare for plotting

# choose a plotting backend: PlotlyJS, GR, PyPlot, etc
# plotlyjs()
# gr()
pyplot()

# pre-set some plotting attributes
labelfontsize  = 16
legendfontsize = 12
tickfontsize   = 13
linewidth = 1.5

c1 = RGB(0, 0, 0.5625)
c2 = RGB(0, 0.5625, 1)
c3 = RGB(0.5, 1, 0.5)
c4 = RGB(1, 0.5, 0)
c5 = RGB(0.5, 0, 0)

x = offset[rxID]/1000


#------------ 1st, Ey Amplitude ------------#
pltEyamp = plot(
            x,
            log10.([Ey0_amp Ey30_amp Ey45_amp Ey60_amp Ey90_amp]),
            label = ["0"   "30"   "45"   "60"  "90"],
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            markersize = 5,
            xlabel = "y (km)",
            ylabel = "log10 (Amplitude (V/m))",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyamp, "Eyamp.pdf")


#-------------- 2nd, Ey Phase --------------#
pltEyphs = plot(
            x,
            [Ey0_phs Ey30_phs Ey45_phs Ey60_phs Ey90_phs],
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            markersize = 5,
            xlabel = "y (km)",
            ylabel = "Phase (degree)",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyphs, "Eyphs.pdf")


#------------ 3rd, Ex Amplitude ------------#
pltExamp = plot(
            x,
            log10.([Ex0_amp Ex30_amp Ex45_amp Ex60_amp Ex90_amp]),
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            markersize = 5,
            xlabel = "y (km)",
            ylabel = "log10 (Amplitude (V/m))",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltExamp, "Examp.pdf")


#-------------- 4th, Ex Phase --------------#
pltExphs = plot(
            x,
            [Ex0_phs Ex30_phs Ex45_phs Ex60_phs Ex90_phs],
            legend = false,
            color = [c1 c2 c3 c4 c5],
            linewidth = linewidth,
            markersize = 5,
            xlabel = "y (km)",
            ylabel = "Phase (degree)",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltExphs, "Exphs.pdf")

#
savefig(pltEyamp, "Eyamp.eps")
savefig(pltEyphs, "Eyphs.eps")
savefig(pltExamp, "Examp.eps")
savefig(pltExphs, "Exphs.eps")



# ======================= Plot normalized responses =======================#
# 1D background and 3D isotropic responses are for normalization purpose
respfile1D = "canonical1D_dp1d.resp"
respfile3D = "canonical3D_sedISO.resp"
(), resp1d = readCSEMResp(respfile1D)
(), resp3d = readCSEMResp(respfile3D)

txID = 1
Ey1d_amp,    = getAmpPhs(resp1d.Ey[rxID, txID, freqID])
Ey3d_amp,    = getAmpPhs(resp3d.Ey[rxID, txID, freqID])

txID = 2
Ex1d_amp,    = getAmpPhs(resp1d.Ex[rxID, txID, freqID])
Ex3d_amp,    = getAmpPhs(resp3d.Ex[rxID, txID, freqID])

Ey0_n1d  = Ey0_amp  ./ Ey1d_amp
Ey30_n1d = Ey30_amp ./ Ey1d_amp
Ey45_n1d = Ey45_amp ./ Ey1d_amp
Ey60_n1d = Ey60_amp ./ Ey1d_amp
Ey90_n1d = Ey90_amp ./ Ey1d_amp

Ey0_n3d  = Ey0_amp  ./ Ey3d_amp
Ey30_n3d = Ey30_amp ./ Ey3d_amp
Ey45_n3d = Ey45_amp ./ Ey3d_amp
Ey60_n3d = Ey60_amp ./ Ey3d_amp
Ey90_n3d = Ey90_amp ./ Ey3d_amp

Ex0_n1d  = Ex0_amp  ./ Ex1d_amp
Ex30_n1d = Ex30_amp ./ Ex1d_amp
Ex45_n1d = Ex45_amp ./ Ex1d_amp
Ex60_n1d = Ex60_amp ./ Ex1d_amp
Ex90_n1d = Ex90_amp ./ Ex1d_amp

Ex0_n3d  = Ex0_amp  ./ Ex3d_amp
Ex30_n3d = Ex30_amp ./ Ex3d_amp
Ex45_n3d = Ex45_amp ./ Ex3d_amp
Ex60_n3d = Ex60_amp ./ Ex3d_amp
Ex90_n3d = Ex90_amp ./ Ex3d_amp


#------------ Ey normalized Amplitude ------------#
pltEyNorAmp = plot(
            x,
            [Ey0_n1d Ey0_n3d Ey30_n1d Ey30_n3d Ey45_n1d Ey45_n3d Ey60_n1d Ey60_n3d Ey90_n1d Ey90_n3d],
            # label = ["0"   "30"   "45"   "60"  "90"],
            legend = false,
            color = [c1 c1 c2 c2 c3 c3 c4 c4 c5 c5],
            linestyle = [:solid :dash],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Normalized field",
            labelfontsize  = labelfontsize,
            legendfontsize = legendfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltEyNorAmp, "EyNorAmp.pdf")


#------------ Ex normalized Amplitude ------------#
pltExNorAmp = plot(
            x,
            [Ex0_n1d Ex0_n3d Ex30_n1d Ex30_n3d Ex45_n1d Ex45_n3d Ex60_n1d Ex60_n3d Ex90_n1d Ex90_n3d],
            legend = false,
            color = [c1 c1 c2 c2 c3 c3 c4 c4 c5 c5],
            linestyle = [:solid :dash],
            linewidth = linewidth,
            xlabel = "y (km)",
            ylabel = "Normalized field",
            labelfontsize  = labelfontsize,
            tickfontsize   = tickfontsize,
            minorticks=true,
            grid = :off,
            xticks = collect(-8:2:8),
            )

savefig(pltExNorAmp, "ExNorAmp.pdf")

#
savefig(pltEyNorAmp, "EyNorAmp.eps")
savefig(pltExNorAmp, "ExNorAmp.eps")
