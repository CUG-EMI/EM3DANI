using SparseArrays
using LinearAlgebra

function spunit(n::Integer)
    return sparse(1.0I, n, n)
end


#
function spdiag((x1,x2), (d1,d2), m, n)
    I, J, V = SparseArrays.spdiagm_internal(d1 => x1, d2 => x2)
    return sparse(I, J, V, m, n)
end


# Form 1D averaging matrix from node to cell-center
function av(n::Integer)
    return spdiag((0.5*ones(n), 0.5*ones(n)), (0,1), n, n+1)
end


# the main function
function getFaceCenterEfield(gridSize::Vector, eField::Array, txID::Int, freqID::Int)
    nx, ny, nz = gridSize

    nEx = nx * (ny+1) * (nz+1)
    nEy = (nx+1) * ny * (nz+1)
    nEz = (nx+1) * (ny+1) * nz


    # use only real part of the E-field
    ext = real( eField[1:nEx, txID, freqID] )
    eyt = real( eField[nEx+1:nEx+nEy, txID, freqID] )
    ezt = real( eField[nEx+nEy+1:end, txID, freqID] )

    # x-y plane
    a_xY = kron(spunit(nz+1), kron(av(ny), spunit(nx)))  # size: (nBz,nEx)
    eXY_ex = a_xY * ext
    a_yX = kron(spunit(nz+1), kron(spunit(ny), av(nx)))  # size: (nBz,nEy)
    eXY_ey = a_yX * eyt

    # x-z plane
    a_xZ = kron(av(nz), kron(spunit(ny+1), spunit(nx)));  # size: (nBy,nEx)
    eXZ_ex = a_xZ * ext
    a_zX = kron(spunit(nz), kron(spunit(ny+1), av(nx)));  # size: (nBy,nEz)
    eXZ_ez = a_zX * ezt

    # y-z plane
    a_yZ = kron(av(nz), kron(spunit(ny), spunit(nx+1)));  # size: (nBx,nEy)
    eYZ_ey = a_yZ * eyt
    a_zY = kron(spunit(nz), kron(av(ny), spunit(nx+1)));  # size: (nBx,nEz)
    eYZ_ez = a_zY * ezt

    # reshape them into 3D arrays
    eXY_ex = reshape(eXY_ex, nx,ny,nz+1)
    eXY_ey = reshape(eXY_ey, nx,ny,nz+1)
    eXZ_ex = reshape(eXZ_ex, nx,ny+1,nz)
    eXZ_ez = reshape(eXZ_ez, nx,ny+1,nz)
    eYZ_ey = reshape(eYZ_ey, nx+1,ny,nz)
    eYZ_ez = reshape(eYZ_ez, nx+1,ny,nz)

    return eXY_ex, eXY_ey, eXZ_ex, eXZ_ez, eYZ_ey, eYZ_ez
end
