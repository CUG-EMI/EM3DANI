

mutable struct MeshTmp{T<:Real}

    xLen::Vector{T}                    # width of cells in x direction
    yLen::Vector{T}                    # width of cells in y direction
    zLen::Vector{T}                    # width of cells in z direction
    airLayer::Vector{T}                # air layer
    seaLayer::Vector{T}                # sea layer
    gridSize::Vector{Int}              # cell numbers in x,y,z direction
    origin::Vector{T}                  # origin of mesh

end


function readMesh(meshfile::String)

    fid = open(meshfile, "r")

    # Initialization
    emp = zeros(0)
    nx   = [];  ny   = [];  nz   = []
    xLen = [];  yLen = [];  zLen = []
    nAir = 0;   airLayer = emp
    nSea = 0;   seaLayer = emp
    origin  = []

    # default form of model parameter: isotropic, linear, conductivity
    condType = "isotropy"
    resType  = "conductivity"
    modType  = "linear"

    sigma  = emp
    sigmax = emp;  sigmay = emp;  sigmaz = emp
    strike = emp;  dip = emp;     slant  = emp
    nBlock = []


    while !eof(fid)

        cline = strip(readline(fid))

        # ignore empty lines and comments (preceded with #)
        isempty(cline)  && continue
        cline[1] == '#' && continue

        # block at x-axis
        if occursin("NX", cline)
            tmp = split(cline)
            nx  = parse(Int, tmp[end])
            nd  = 0
            xLen = zeros(nx)

            while nd < nx
                cline = strip(readline(fid))
                cline = split(cline)
                num = length(cline)
                for i = 1:num
                    nd = nd + 1
                    xLen[nd] = parse(Float64, cline[i])
                end
            end

        # block at y-axis
        elseif occursin("NY", cline)
            tmp = split(cline)
            ny  = parse(Int, tmp[end])
            nd  = 0
            yLen = zeros(ny)

            while nd < ny
                cline = strip(readline(fid))
                cline = split(cline)
                num = length(cline)
                for i = 1:num
                    nd = nd + 1
                    yLen[nd] = parse(Float64, cline[i])
                end
            end

        # block at z-axis
        elseif occursin("NZ", cline)
            tmp = split(cline)
            nz  = parse(Int, tmp[end])
            nd  = 0
            zLen = zeros(nz)

            while nd < nz
                cline = strip(readline(fid))
                cline = split(cline)
                num = length(cline)
                for i = 1:num
                    nd = nd + 1
                    zLen[nd] = parse(Float64, cline[i])
                end
            end

            nBlock = nx * ny * nz

        # air layer
        elseif occursin("NAIR", cline)
            tmp = split(cline)
            nAir  = parse(Int, tmp[end])
            nd  = 0
            airLayer = zeros(nAir)

            while nd < nAir
                cline = strip(readline(fid))
                cline = split(cline)
                num = length(cline)
                for i = 1:num
                    nd = nd + 1
                    airLayer[nd] = parse(Float64, cline[i])
                end
            end

        elseif occursin("NSEA", cline)
            tmp = split(cline)
            nSea = parse(Int, tmp[end])
            nd  = 0
            seaLayer = zeros(nSea)

            while nd < nSea
                cline = strip(readline(fid))
                cline = split(cline)
                num = length(cline)
                for i = 1:num
                    nd = nd + 1
                    seaLayer[nd] = parse(Float64, cline[i])
                end
            end


        # origin
        elseif occursin("Origin", cline)
            tmp = split(cline)
            origin = zeros(3)
            origin[1] = parse(Float64, tmp[end-2])
            origin[2] = parse(Float64, tmp[end-1])
            origin[3] = parse(Float64, tmp[end])

        end # if

    end # while !eof(fid)

    close(fid)

    ## assembly
    airDep = sum(airLayer)
    seaDep = sum(seaLayer)
    zLen = [reverse(airLayer, dims=1); seaLayer; zLen]
    nz   = length(zLen)

    origin[3] = origin[3] + airDep


    gridSize = vec([nx ny nz])
    mesh = MeshTmp(xLen, yLen, zLen, airLayer, seaLayer, gridSize, origin)

    return mesh

end
