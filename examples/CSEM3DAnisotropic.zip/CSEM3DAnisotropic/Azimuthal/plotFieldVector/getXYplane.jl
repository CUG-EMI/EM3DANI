function meshgrid(vx::AbstractVector{T}, vy::AbstractVector{T}) where{T}
	m, n = length(vy), length(vx)
	vx = reshape(vx, 1, n)
	vy = reshape(vy, m, 1)
	(repeat(vx, m, 1), repeat(vy, 1, n))
end


function getXYplane(zfix, xrange, yrange, mesh, eXY_ex, eXY_ey)

	# grid node coordiantes

    xNode = cumsum([0; mesh.xLen]) .- mesh.origin[1]
    yNode = cumsum([0; mesh.yLen]) .- mesh.origin[2]
    zNode = cumsum([0; mesh.zLen]) .- mesh.origin[3]

	# cell center coordiantes
	xCen = xNode[1:end-1] + mesh.xLen / 2
    yCen = yNode[1:end-1] + mesh.yLen / 2
    zCen = zNode[1:end-1] + mesh.zLen / 2


	zdif = abs.(zNode .- zfix)
	iz = findall(zdif .== minimum(zdif))

	ydif = abs.(yNode .- yrange[1])
	iy1 = findall(ydif .== minimum(ydif))
	length(iy1)>1 && ( iy1 = iy1[1] )
	ydif = abs.(yNode .- yrange[2])
	iy2 = findall(ydif .== minimum(ydif))
	length(iy2)>1 && ( iy2 = iy2[2] )

	xdif = abs.(xNode .- xrange[1])
	ix1 = findall(xdif .== minimum(xdif))
	length(ix1)>1 && ( ix1 = ix1[1] )
	xdif = abs.(xNode .- xrange[2])
	ix2 = findall(xdif .== minimum(xdif))
	length(ix2)>1 && ( ix2 = ix2[2] )

	iz = iz[1]
	iy1 = iy1[1];  iy2 = iy2[1]
	ix1 = ix1[1];  ix2 = ix2[1]


	# extract fields and reshape them into 2d arrays
	ex0 = eXY_ex[ix1:ix2-1, iy1:iy2-1, iz]
	ey0 = eXY_ey[ix1:ix2-1, iy1:iy2-1, iz]

	# get coordinates of the selected points,
	yc = yCen[iy1:iy2-1]/1000   # from m to km
	xc = xCen[ix1:ix2-1]/1000

	YY, XX = meshgrid(yc, xc)

	# a tip to make the lengths of all arrows same without changing their directions
	ey0n = ey0 ./ sqrt.(ey0.^2+ex0.^2)
	ex0n = ex0 ./ sqrt.(ey0.^2+ex0.^2)

	AMP = log10.(sqrt.(ey0.^2+ex0.^2))

	return XX, YY, AMP, ex0n, ey0n
end
