#------------------------------------------------------------------------------
# script to plot CSEM forward modeling results
#------------------------------------------------------------------------------

using Plots
using Printf
using DSP
#------------------------------------------------------------------------------

include("readMesh.jl")
include("readEdgeFields.jl")
include("getFaceCenterEfield.jl")
include("getXYplane.jl")


# First, read the mesh file
println("Reading mesh file ...")
@time mesh = readMesh("mesh.mesh")

# Second, read the primary fields
EpFile = "Ep.txt"
println("Reading Ep field file ...")
@time epField, gridSize = readEdgeFields(EpFile)

# Third, read the secondary fields
EsFile = "E_sedTTI_strike0.field"
println("Reading Es field file ...")
@time eField,           = readEdgeFields(EsFile)

eField += epField  # get the total field


# 4th, select a period and a polarization mode
freqID = 1  # 0.25Hz
txID   = 1  # inline

println("Getting face center E field ...")
@time eXY_ex, eXY_ey, = getFaceCenterEfield(gridSize, eField, txID, freqID)

# select a specific x-y section
zfix = 1200
xrange = [-4000 4000]
yrange = [-6400 6400]

println("Extracting the fields of selected plane ...")
@time XX, YY, AMP, ex0n, ey0n = getXYplane(zfix, xrange, yrange, mesh, eXY_ex, eXY_ey)


# Then, prepare for plotting
# choose a plotting backend: PlotlyJS, GR, PyPlot, etc
# plotlyjs()
# gr()
pyplot()

labelfontsize  = 16
tickfontsize   = 13

w2h = (yrange[2]-yrange[1])/(xrange[2]-xrange[1])
window_h = 400
window_w = window_h * w2h

# plot the contours.
p1 = contourf(YY, XX, AMP,
              levels=100,
              #yflip=true,
              c = :jet1,
              clims = (-16, -8),
              aspect_ratio=:equal,
              xlabel = "y (km)",
              ylabel = "x (km)",
			  labelfontsize  = labelfontsize,
		      tickfontsize   = tickfontsize,
              #cbar = colorbar(ticks=collect(-16:2:-8)),
              #colorbar_title = "Amplitude, log10 (V/m)",
			  colorbar = false,
              foreground_color_grid=RGB(0.8, 0.8, 0.8),
              gridstyle=:dash,
              #ylims = (-0.2, 4.3),
              #yticks = collect(0:4),
              xticks = collect(-6:2:6),
              windowsize = (window_w, window_h))

# plot the vectors.
n1, n2 = size(YY)
yidx = 1:2:n1
xidx = vcat([1, 2, 3], collect(4:2:n2-3), [n2-2, n2-1, n2])
quiver!(YY[yidx,xidx][:], XX[yidx,xidx][:],
        quiver = (ey0n[yidx,xidx][:]*0.15, ex0n[yidx,xidx][:]*0.15),
        c = RGB(0.15, 0.15, 0.15),
        linewidth = 0.35,
        arrow = 0.1)


# plot the outline of the rectangle anomaly.
yloc = [-3, 3, 3, -3, -3]
xloc = [3, 3, -3, -3, 3]
plot!(yloc, xloc, c=:white, linestyle = :dash, linewidth=2, legend = false)



# plot the long arrow
alen   = 3.0    # arrow lenth
angle  = 90.0   # arrow angle
#= startPoint = [3, 0]
quiver!([3], [0],
        quiver = ([alen*sind(angle)], [alen*cosd(angle)]),
        c = :black,
        linewidth = 0.8,
		arrow = 1,5
        )
=#
savefig(p1, "Exy_0.pdf")
savefig(p1, "Exy_0.eps")
